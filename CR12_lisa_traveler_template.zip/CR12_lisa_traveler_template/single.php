<?php
get_header();
?>
<div class="main-wrapper ">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><span><?php single_post_title();?></span></h1>
    </header>

    <div class='container col-12 mt-3 mb-3 mx-auto'>
        <h2 class="heading"><?php single_cat_title();?></h2>
        <?php if (have_posts()) : while(have_posts()): the_post();?>

            <div class="m-5 ">
                <h3 class="text-center m-5"><?php the_title();?></h3>
                <p><?php the_content();?></p>

                <p class=" d-flex justify-content-end">
                    <?php the_time('F j, Y g:i a'); ?></p>
                <div class="d-flex justify-content-center"><?php comments_template();?></div>
            </div>

        <?php endwhile;endif;?>

    </div>

    <?php
    get_footer();
    ?>
