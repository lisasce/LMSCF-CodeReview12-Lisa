<?php
get_header();
?>
<div class="main-wrapper">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><span><?php single_post_title();?></span></h1>
    </header>
    <article class="content px-3 py-5 p-md-5">
        <div class='container'>
            <h3 class='text-center'>Welcome to <?php bloginfo( 'name' ); ?> - your Travel organisator!</h3>
            <p class="mt-3 lead text-center">Short presentation of your travel webpage hard coded. <br>
                    <strong>or: the dynamic description </strong> written in wordpress: <br>
                <strong>  <?php bloginfo( 'description' ); ?></strong> </p>



            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://cdn.pixabay.com/photo/2017/10/23/05/56/holiday-2880261_960_720.jpg" class="d-block w-100" alt="1">
                    </div>
                    <div class="carousel-item">
                        <img src="https://cdn.pixabay.com/photo/2018/03/12/20/07/maldives-3220702_960_720.jpg" class="d-block w-100" alt="2">
                    </div>
                    <div class="carousel-item">
                        <img src="https://cdn.pixabay.com/photo/2016/10/18/08/13/travel-1749508_960_720.jpg" class="d-block w-100" alt="3">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

            <?php if (have_posts()) : while(have_posts()): the_post();?>

               <div class="text-center mt-2"> <?php the_content();?></div>

            <?php endwhile;endif;?>

            <div class="row row-cols-1 mt-4 row-cols-md-2">
                <div class="col mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                    </div>
                </div>
                <div class="col mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                    </div>
                </div>
            </div>
    </article>



<?php
get_footer();
?>
</div>
