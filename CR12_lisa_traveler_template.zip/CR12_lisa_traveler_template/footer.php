<?php
wp_footer();
?>
<!-- Bootstrap Javascript -->
<footer class="footer text-center py-2 theme-bg-dark">

    <p class="copyright">2020-Lisa</p>

</footer>

</body>
</html>
