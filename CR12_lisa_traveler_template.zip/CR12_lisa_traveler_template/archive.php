<?php
get_header();
?>
<div class="main-wrapper">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><span><?php single_cat_title(); ?></span></h1>
    </header>
    <div class='container'>
        <?php if (have_posts()) : while(have_posts()): the_post();?>
            <h3><?php the_title() ?></h3>
            <?php the_excerpt();?>
            <p class=" d-flex justify-content-around"><a href="<?php the_permalink(); ?>" class="btn btn-light">Read more</a>
                <?php the_time('F j, Y g:i a'); ?></p>
        <?php endwhile;endif;?>

    </div>

    <?php
    get_footer();
    ?>

