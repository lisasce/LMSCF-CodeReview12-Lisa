<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Blog Site Template">
    <meta name="author" content="https://youtube.com/FollowAndrew">
    <link rel="shortcut icon" href="images/logo.png">

    <!-- FontAwesome CSS-->
    <!-- Bootstrap CSS-->
    <!-- Theme CSS -->

    <?php
    wp_head();
    ?>

</head>

<body <?php body_class();?>>

<header class="header text-center">
    <a class="site-title pt-lg-4 mb-0" href="index.php"><?php bloginfo( 'name' ); ?></a>
        <nav class="navbar navbar-expand-lg navbar-light" >

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div id="navigation" class="collapse navbar-collapse flex-column" >
                <img class="mb-5 mx-auto logo" src="https://cdn.pixabay.com/photo/2013/07/13/11/36/volkswagen-158463_960_720.png" alt="logo" >

                <ul class="navbar-nav flex-column text-sm-center text-md-left">


    <?php wp_nav_menu(
        array(
            'theme_location'=>'left-menu',
            'menu_class'=> 'nav-item',
            'sub-menu'=> 'dropdown-item'
        )
    );?>

                </ul>

            </div>
        </nav>

</header>

