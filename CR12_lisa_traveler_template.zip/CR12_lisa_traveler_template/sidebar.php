<div id="sidebar" class="col-12 col-sm-3 bg-light mt-3 mx-auto">

<?php
if(is_active_sidebar('sidebar')):
    dynamic_sidebar('sidebar');
endif;
?>

</div>
