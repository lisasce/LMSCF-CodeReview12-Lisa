<?php
get_header();
?>
    <div class="main-wrapper">
        <header class="page-title theme-bg-light text-center gradient py-5">
            <h1 class="heading"><span><?php single_post_title();?></span></h1>
        </header>
        <article class="content px-3 py-5 p-md-5">
            <div class='container'>

                <?php if (have_posts()) : while(have_posts()): the_post();?>

                    <?php the_content();?>

                <?php endwhile;endif;?>

            </div>


        </article>


    </div>
<?php
get_footer();
?>
