<?php
get_header();
?>
<div class="main-wrapper">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><span><?php single_post_title();?></span></h1>
    </header>


<p> page not found sorry</p>

</div>
<?php
get_footer();
?>
