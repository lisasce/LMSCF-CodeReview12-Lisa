<?php
get_header();
?>
<div class="main-wrapper">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><span><?php single_post_title();?></span></h1>
    </header>

    <div class="container-fluid row">

        <div class='col-12 col-sm-9'>
<?php if (have_posts()) : while(have_posts()): the_post();?>

    <div class="m-3 p-2 card">
        <h3 class="text-center m-1"><?php the_title();?></h3>
        <?php if(has_post_thumbnail()):?>
            <img src="<?php the_post_thumbnail_url('small');?>" class="img-fluid p-5">
        <?php endif;?>
        <p class="pl-2"><?php the_excerpt(); ?></p>
        <p class=" d-flex justify-content-around"><a href="<?php the_permalink(); ?>" class="btn btn-light">Read more</a>
            <?php the_time('F j, Y g:i a'); ?></p>
    </div>
<?php endwhile;endif;?>

        </div>
        <?php get_sidebar();?>

    </div>
<?php
get_footer();
?>

